
@echo off
setlocal
cd /d "%~dp0"
set "PY_CMD=py -3"
py -3 -c "import sys; assert sys.version_info >= (3, 11)" >nul 2>nul
if errorlevel 1 (
  set "PY_CMD=python"
  python -c "import sys; assert sys.version_info >= (3, 11)" >nul 2>nul
  if errorlevel 1 (
    echo Install Python 3.11 or newer from https://www.python.org/downloads/ then reopen START.cmd.
    pause
    exit /b 1
  )
)
if not exist ".venv\Scripts\python.exe" (
  echo Preparing the app for first use...
  %PY_CMD% -m venv .venv
  if errorlevel 1 goto setup_error
)
".venv\Scripts\python.exe" -c "import importlib.metadata as m; assert m.version('requests') == '2.34.2'; assert m.version('openpyxl') == '3.1.5'" >nul 2>nul
if errorlevel 1 (
  echo Installing the Python packages. Internet is needed for this first step.
  ".venv\Scripts\python.exe" -m pip install -r requirements.txt
  if errorlevel 1 goto setup_error
)
".venv\Scripts\python.exe" app.py
if errorlevel 1 goto runtime_error
exit /b 0
:runtime_error
echo The app stopped because of an error. Review the message above.
pause
exit /b 1
:setup_error
echo Setup did not finish. Check your internet connection and folder permissions, then try again.
pause
exit /b 1

