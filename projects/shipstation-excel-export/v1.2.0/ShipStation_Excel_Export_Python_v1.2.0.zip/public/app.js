
const reportForm = document.getElementById("reportForm");
const credentialsFile = document.getElementById("credentialsFile");
const shipDate = document.getElementById("shipDate");
const reportButton = document.getElementById("reportButton");
const exitButton = document.getElementById("exitButton");

const statusMessage = document.getElementById("statusMessage");
const progressBar = document.getElementById("progressBar");
const sectionValue = document.getElementById("sectionValue");
const pageValue = document.getElementById("pageValue");
const timeValue = document.getElementById("timeValue");


// ----------- 1 - DEFAULT DATE -----------


function setTodaysDate() {
    const today = new Date();
    const month = String(today.getMonth() + 1).padStart(2, "0");
    const day = String(today.getDate()).padStart(2, "0");
    const year = today.getFullYear();

    shipDate.value = `${month}/${day}/${year}`;
}


// ----------- 2 - STATUS DISPLAY -----------


function formatTime(seconds) {
    if (!Number.isFinite(seconds)) {
        return "—";
    }

    if (seconds < 60) {
        return `${Math.max(0, Math.ceil(seconds))} seconds`;
    }

    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = Math.ceil(seconds % 60);
    return `${minutes} min ${remainingSeconds} sec`;
}


function showProgress(update) {
    statusMessage.textContent = update.message || "Working...";

    if (update.section) {
        sectionValue.textContent = update.section;
    }

    if (update.currentPage && update.totalPages) {
        pageValue.textContent = `${update.currentPage} of ${update.totalPages}`;
        progressBar.style.width = `${Math.min(100, (update.currentPage / update.totalPages) * 100)}%`;
    }

    if (update.estimatedSeconds !== undefined) {
        timeValue.textContent = formatTime(update.estimatedSeconds);
    }
}


function showError(message) {
    statusMessage.textContent = message;
    statusMessage.className = "error-message";
    reportButton.disabled = false;
    reportButton.textContent = "Create Excel Report";
}


// ----------- 3 - DOWNLOAD EXCEL -----------


function downloadExcel(base64File, reportDate) {
    const binaryText = window.atob(base64File);
    const fileBytes = new Uint8Array(binaryText.length);

    for (let index = 0; index < binaryText.length; index += 1) {
        fileBytes[index] = binaryText.charCodeAt(index);
    }

    const excelFile = new Blob(
        [fileBytes],
        {type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"}
    );

    const downloadLink = document.createElement("a");
    downloadLink.href = URL.createObjectURL(excelFile);
    downloadLink.download = `ShipStation_${reportDate}_Report.xlsx`;
    downloadLink.click();

    URL.revokeObjectURL(downloadLink.href);
}


// ----------- 4 - READ PROGRAM MESSAGES -----------


async function readReportMessages(response) {
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let unfinishedText = "";

    while (true) {
        const result = await reader.read();
        unfinishedText += decoder.decode(result.value || new Uint8Array(), {stream: !result.done});

        const lines = unfinishedText.split("\n");
        unfinishedText = lines.pop();

        for (const line of lines) {
            if (!line.trim()) {
                continue;
            }

            const message = JSON.parse(line);

            if (message.type === "progress") {
                showProgress(message);
            }

            if (message.type === "error") {
                throw new Error(message.message);
            }

            if (message.type === "complete") {
                downloadExcel(message.report.fileBase64, message.report.shipDate);
                statusMessage.textContent = `Complete. ${message.report.rowCount} Excel row(s) created and ${message.report.printJobCount} Windows print record(s) checked.`;
                statusMessage.className = "success-message";
                progressBar.style.width = "100%";
                sectionValue.textContent = "Complete";
                pageValue.textContent = "Done";
                timeValue.textContent = "0 seconds";
            }
        }

        if (result.done) {
            break;
        }
    }
}


// ----------- 5 - CREATE REPORT -----------


reportForm.addEventListener("submit", async function (event) {
    event.preventDefault();

    if (!credentialsFile.files.length) {
        showError("Choose the ShipStation API TXT file.");
        return;
    }

    reportButton.disabled = true;
    reportButton.textContent = "Creating Report...";
    statusMessage.className = "";
    progressBar.style.width = "2%";
    sectionValue.textContent = "Starting";
    pageValue.textContent = "—";
    timeValue.textContent = "Calculating";

    try {
        const credentialsText = await credentialsFile.files[0].text();
        const response = await fetch("/api/report", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({
                credentialsText: credentialsText,
                shipDate: shipDate.value.trim()
            })
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || "The report could not be created.");
        }

        await readReportMessages(response);
    } catch (error) {
        showError(error.message || "The report could not be created.");
    } finally {
        reportButton.disabled = false;
        reportButton.textContent = "Create Excel Report";
    }
});


// ----------- 6 - EXIT PROGRAM -----------


exitButton.addEventListener("click", async function () {
    exitButton.disabled = true;
    statusMessage.textContent = "Closing the program...";

    try {
        await fetch("/api/exit", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: "{}"
        });
    } finally {
        document.body.innerHTML = "<main class='closed-message'><h1>Program closed</h1><p>You may close this browser tab.</p></main>";
    }
});


setTodaysDate();

