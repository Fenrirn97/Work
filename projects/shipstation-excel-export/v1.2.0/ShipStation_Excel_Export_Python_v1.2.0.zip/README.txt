
SHIPSTATION EXCEL EXPORT — PYTHON — VERSION 1.2.0

WHAT THE PROGRAM DOES

1. Reads the ShipStation API key from the TXT file you choose.
2. Reads Shipments and Fulfillments for the Ship Date you enter.
3. Gets each order's item name, SKU, quantity, Order Date, tracking and carrier.
4. Checks this Windows computer's completed print-job records for matching numbers.
5. Downloads one Excel workbook. The program never prints a document.

START THE PROGRAM ON WINDOWS

1. Install Python 3.11 or newer if needed:
   https://www.python.org/downloads/
2. Extract the entire ZIP. Do not run it from inside the ZIP.
3. Double-click START.cmd.
4. The first start installs Requests and openpyxl into the program's .venv folder.
5. Your browser opens automatically. If it does not, open http://127.0.0.1:8787.
6. Choose the API TXT file, enter Ship Date as MM/DD/YYYY, and click
   Create Excel Report.
7. Click the red Exit Program button when finished. This stops Python completely.

Keep the terminal window open while the program is running. No Node.js is needed.

API KEY TXT FILE

Version 1 is recommended because it can provide fuller original-order details:

API_KEY=your_actual_v1_key
API_SECRET=your_actual_v1_secret

For Version 2 use:

V2_API_KEY=your_actual_v2_key

You can also put one V2 key by itself on one line. Do not mix V1 and V2 keys.
Replace the ShipStation API credentials at least every 6 months, update your local
TXT file, and remove the old key in ShipStation. Never commit the TXT file to GitHub.

TODAY COMPARED WITH AN EARLIER DATE

For today's date, Version 1 reads only orders connected to today's shipment and
fulfillment records. This is the faster path.

For any earlier date, Version 1 checks every page of orders currently marked
Shipped. This slower scan is intentional because an order may have been placed on
an older day and marked shipped later by Amazon, Walmart or another provider.
The screen shows the current page and recalculates the estimated remaining time.

WHAT IS IN EXCEL

The first sheet is named with the selected date and includes:

- Order Number
- Item Name
- SKU
- Quantity
- Order Date
- Ship Date
- Tracking Number
- Carrier
- Unit Price and Line Total
- Store, recipient and ShipStation IDs
- Print Status, print time, printer, computer and matched document name

Tracking Records keeps the raw daily shipment and fulfillment matches.
Print History contains only Windows print jobs matched to a ShipStation identifier.
Read Me explains missing fields and limitations.

PRINT-HISTORY CHECK

The program never prints. It only reads Windows PrintService Event 307 records.
Those records must already exist before the report runs.

To enable the Windows log:

1. Open Event Viewer.
2. Go to Applications and Services Logs > Microsoft > Windows > PrintService.
3. Right-click Operational and choose Enable Log.

Windows must keep a useful document name for automatic matching. The program looks
for a tracking number first, then the order number, Shipment ID or Record ID inside
the print-job document name. A downloaded file that was never sent to a Windows
printer will not create Event 307.

Print Status meanings:

- Printed - Windows record found: a completed spooler record matched an identifier.
- No matching print record: the log was available but no useful match was found.
- Unknown - print log unavailable: Windows logging was disabled or could not be read.

"Printed" means Windows completed the spooler job. It does not prove the paper came
out correctly. "No matching print record" does not prove it was never printed. The
job may have used a generic name, occurred before logging was enabled, or been sent
from another computer.

This version checks only the Windows computer running the program. To cover several
packing computers, run it where their jobs pass through a shared print server or
collect each computer's logs into one shared source in a later version.

PRIVACY AND SAFETY

The program runs only at 127.0.0.1 on your computer. It uses read-only ShipStation
API calls. Credentials and the report stay in memory until the browser downloads
the Excel file. API secrets are not written to application logs or the workbook.
The downloaded workbook contains order data, so store it securely.

SOURCE CODE GUIDE

The source uses direct names and numbered sections so it is easier to follow:

- app.py: starts the local website and handles Create Report / Exit Program.
- shipstation.py: validates input, calls ShipStation and combines the order data.
- print_history.py: reads Windows print records and matches document names.
- excel_export.py: creates the four Excel worksheets.
- public/local/index.html: the page structure.
- public/app.js: the buttons, progress updates and Excel download.
- public/style.css: the page colors and layout.
- tests/test_export.py: synthetic tests; it does not use a real API account.

The code is intentionally plain and avoids a framework or JavaScript build step.
The API retry, pagination and input checks remain because removing them could create
an incomplete report or expose an API key.

MANUAL START

Windows:

py -3 -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe app.py

Mac or Linux: use python3 -m venv .venv and .venv/bin/python for the last
two commands. Windows print-history checking is unavailable on Mac and Linux.

TESTS

python -m unittest discover -s tests -v

The 15 tests use synthetic ShipStation and Windows print-history responses. Compare
the first real export with the ShipStation Shipped screen before relying on it.

OFFICIAL REFERENCES

https://www.shipstation.com/docs/api/orders/list-orders/
https://www.shipstation.com/docs/api/fulfillments/list-fulfillments/
https://docs.shipstation.com/apis/openapi/fulfillments/list_fulfillments
https://learn.microsoft.com/windows/win32/printdocs/printing-and-print-spooler
https://requests.readthedocs.io/en/latest/user/quickstart/
https://openpyxl.readthedocs.io/en/stable/tutorial.html

